class MyClass2:
    x = True
