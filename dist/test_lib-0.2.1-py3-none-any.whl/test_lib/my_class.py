class MyClass:
    def my_test_function(self):
        return "test function"
